# Miz Readz-a-Lot — Hackathon Edition

A fabulous, sassy, AI-powered career coach with drag queen energy, here to “read” your career path with wit, tough love, and actionable advice.

## Features
- AI chat with memory
- PDF Glow-Up Career Reports
- Skill Gap Analyzer
- Career Path Mapper

## Setup
1. Clone this repo
2. Run `npm install`
3. Add your OpenAI API key to `.env`:
```
VITE_OPENAI_API_KEY=your_api_key_here
```
4. Run `npm run dev`
