import { useState } from "react";
import ChatBox from "./components/ChatBox";
import ReportModal from "./components/ReportModal";

export default function App() {
  const [reportText, setReportText] = useState("");

  return (
    <div className="app">
      <h1 className="title">💅 Miz Readz-a-Lot</h1>
      <p className="subtitle">Your fabulous, sassy, and actually helpful career coach</p>
      <ChatBox onReportReady={setReportText} />
      {reportText && <ReportModal text={reportText} />}
    </div>
  );
}
