export async function getMizAdvice(conversationHistory: { role: string, content: string }[]) {
  const API_KEY = import.meta.env.VITE_OPENAI_API_KEY;

  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${API_KEY}`
    },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: "You are Miz Readz-a-Lot, a fabulous drag queen career coach who gives sassy but structured, professional career advice with clear steps and resources." },
        ...conversationHistory
      ],
      temperature: 0.8
    })
  });

  const data = await res.json();
  return data.choices[0].message.content;
}
