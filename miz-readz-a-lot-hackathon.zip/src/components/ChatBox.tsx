import { useState } from "react";
import { getMizAdvice } from "../api";

export default function ChatBox({ onReportReady }: { onReportReady: (text: string) => void }) {
  const [messages, setMessages] = useState<{role: string, content: string}[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  async function sendMessage() {
    if (!input.trim()) return;
    const newMessages = [...messages, { role: "user", content: input }];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    const reply = await getMizAdvice(newMessages);
    const updatedMessages = [...newMessages, { role: "assistant", content: reply }];
    setMessages(updatedMessages);
    onReportReady(reply);
    setLoading(false);
  }

  return (
    <div className="chatbox">
      <div className="messages">
        {messages.map((m, i) => (
          <div key={i} className={m.role}>
            <strong>{m.role === "user" ? "You" : "Miz Readz"}:</strong> {m.content}
          </div>
        ))}
        {loading && <p>💅 Miz is thinking...</p>}
      </div>
      <div className="input-area">
        <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Spill your career tea..." />
        <button onClick={sendMessage}>Send</button>
      </div>
    </div>
  );
}
