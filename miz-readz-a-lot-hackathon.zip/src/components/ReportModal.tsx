import { jsPDF } from "jspdf";

export default function ReportModal({ text }: { text: string }) {
  function downloadPDF() {
    const doc = new jsPDF();
    doc.text("💎 Miz Readz-a-Lot's Career Glow-Up Report", 10, 10);
    doc.text(text, 10, 20);
    doc.save("MizReadzGlowUp.pdf");
  }

  return (
    <div>
      <button onClick={downloadPDF} className="download-btn">Download Glow-Up Report</button>
    </div>
  );
}
